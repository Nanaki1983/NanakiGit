# Wheel of Names

## Overview
The Wheel of Names is a simple offline application that allows users to input names and randomly select one using a spinning wheel interface. This project is designed to be user-friendly and visually appealing.

## Features
- Add multiple names to the wheel.
- Spin the wheel to randomly select a name.
- Responsive design for various screen sizes.

## Project Structure
```
wheel-of-names
├── src
│   ├── index.html        # Main HTML document
│   ├── styles
│   │   └── style.css     # Styles for the application
│   ├── scripts
│       └── app.js        # JavaScript functionality
├── package.json          # npm configuration file
└── README.md             # Project documentation
```

## Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd wheel-of-names
   ```
3. Open `src/index.html` in your web browser to run the application offline.

## Usage
- Enter names in the input field.
- Click the "Add Name" button to add names to the wheel.
- Click the "Spin" button to spin the wheel and select a random name.

## Contributing
Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License
This project is licensed under the MIT License. See the LICENSE file for details.