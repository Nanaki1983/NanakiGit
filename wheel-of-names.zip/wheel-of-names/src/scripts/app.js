const canvas = document.getElementById('wheel');
const ctx = canvas.getContext('2d');
const namesInput = document.getElementById('namesInput');
const updateButton = document.getElementById('updateButton');
const spinButton = document.getElementById('spinButton');
const removeWinnerButton = document.getElementById('removeWinnerButton');
const restartButton = document.getElementById('restartButton');
const customizeButton = document.getElementById('customizeButton');
const customizeSliders = document.getElementById('customizeSliders');
const minSpinTime = document.getElementById('minSpinTime');
const maxSpinTime = document.getElementById('maxSpinTime');
const spinSpeedSlider = document.getElementById('spinSpeed');
const minSpinTimeValue = document.getElementById('minSpinTimeValue');
const maxSpinTimeValue = document.getElementById('maxSpinTimeValue');
const spinSpeedValue = document.getElementById('spinSpeedValue');
const winnerDiv = document.getElementById('winner');
const removedNamesDiv = document.getElementById('removedNames');
let names = namesInput.value.split('\n').map(name => name.trim()).filter(name => name);
const initialNames = [...names];
const colors = ['#FF5733', '#33FF57', '#3357FF', '#FF33A1', '#A133FF', '#33FFF5'];
let numSegments = names.length;
let currentAngle = 0;
let idleRotationSpeed = 0.01; // Speed of idle rotation
let spinSpeed = 0;
let isSpinning = false;
let winnerAngle = null;
let winner = null;
let spinDuration = 0;
let startTime = null;

function drawWheel() {
    numSegments = names.length;
    const anglePerSegment = (2 * Math.PI) / numSegments;
    for (let i = 0; i < numSegments; i++) {
        const startAngle = currentAngle + i * anglePerSegment;
        const endAngle = startAngle + anglePerSegment;
        ctx.beginPath();
        ctx.moveTo(canvas.width / 2, canvas.height / 2);
        ctx.arc(canvas.width / 2, canvas.height / 2, canvas.width / 2, startAngle, endAngle);
        ctx.fillStyle = colors[i % colors.length];
        ctx.fill();
        ctx.stroke();
        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((startAngle + endAngle) / 2);
        ctx.textAlign = 'right';
        ctx.fillStyle = '#000';
        ctx.font = '20px Arial';
        ctx.fillText(names[i], canvas.width / 2 - 10, 10);
        ctx.restore();
    }
}

function update(timestamp) {
    if (isSpinning) {
        if (!startTime) startTime = timestamp;
        const elapsed = (timestamp - startTime) / 3000; // Convert to seconds
        const totalDuration = parseFloat(maxSpinTime.value);
        const progress = elapsed / totalDuration;
        spinSpeed = parseFloat(spinSpeedSlider.value) * Math.exp(-3 * progress); // Exponential decay

        if (progress >= 1) {
            spinSpeed = 0;
            isSpinning = false;
            declareWinner();
        }
    } else {
        currentAngle += idleRotationSpeed;
    }
    currentAngle += spinSpeed;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawWheel();
    if (isSpinning) {
        requestAnimationFrame(update);
    }
}

function declareWinner() {
    const anglePerSegment = (2 * Math.PI) / numSegments;
    const winningIndex = Math.floor((currentAngle % (2 * Math.PI)) / anglePerSegment);
    winner = names[(numSegments - winningIndex) % numSegments];
    winnerDiv.textContent = `Winner: ${winner}`;
    winnerAngle = currentAngle - (currentAngle % anglePerSegment) + (anglePerSegment / 2);
    removeWinnerButton.style.display = 'block';
}

updateButton.addEventListener('click', () => {
    names = namesInput.value.split('\n').map(name => name.trim()).filter(name => name);
    winnerAngle = null;
    drawWheel();
});

spinButton.addEventListener('click', () => {
    if (!isSpinning) {
        spinSpeed = parseFloat(spinSpeedSlider.value); // Use spin speed from slider
        spinDuration = parseFloat(maxSpinTime.value); // Use max spin time from slider
        isSpinning = true;
        startTime = null; // Reset start time for new spin
        winnerDiv.textContent = ''; // Clear previous winner
        winnerAngle = null;
        removeWinnerButton.style.display = 'none';
        updateButton.disabled = true; // Disable update button after first spin
        restartButton.style.display = 'block'; // Show restart button
        requestAnimationFrame(update);
    }
});

removeWinnerButton.addEventListener('click', () => {
    if (winner) {
        names = names.filter(name => name !== winner);
        const removedNameElement = document.createElement('div');
        removedNameElement.textContent = winner;
        removedNamesDiv.appendChild(removedNameElement);
        winner = null;
        drawWheel();
        removeWinnerButton.style.display = 'none';
    }
});

restartButton.addEventListener('click', () => {
    names = [...initialNames];
    namesInput.value = initialNames.join('\n');
    removedNamesDiv.innerHTML = '';
    winnerDiv.textContent = '';
    winner = null;
    winnerAngle = null;
    updateButton.disabled = false; // Enable update button
    restartButton.style.display = 'none'; // Hide restart button
    drawWheel();
});

customizeButton.addEventListener('click', () => {
    customizeSliders.style.display = customizeSliders.style.display === 'none' ? 'block' : 'none';
});

minSpinTime.addEventListener('input', () => {
    minSpinTimeValue.textContent = minSpinTime.value;
});

maxSpinTime.addEventListener('input', () => {
    maxSpinTimeValue.textContent = maxSpinTime.value;
});

spinSpeedSlider.addEventListener('input', () => {
    spinSpeedValue.textContent = spinSpeedSlider.value;
});

namesInput.addEventListener('focus', () => {
    if (namesInput.value === 'Enter names here...') {
        namesInput.value = '';
    }
});

namesInput.addEventListener('blur', () => {
    if (namesInput.value === '') {
        namesInput.value = 'Enter names here...';
    }
});

drawWheel();